const LVLTIMER = 90; //level per second
const MAXWINCOUNT = 10;
const MAXTIME = 120;