var counter = 0, isResize = 0, isResize = 0;
var scene, camera, renderer, gameUI, mTube = [];
var CANVAS_WIDTH = 480, CANVAS_HEIGHT = 854;
var mPlayer = new Player();
var mPush = new PushPop();
var mPop = new PushPop();
var raycaster = new THREE.Raycaster();

var mTex_Continue;

function init() {
    camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 0, 300); camera.rotation.set(0, 0, 0);
    camera.position.set(sx, 50, 300); camera.rotation.set(-.4, 0, 0);
    scene = new THREE.Scene(); scene.background = new THREE.Color(0x000000);
    var manager = new THREE.LoadingManager(loadModel);
    manager.onProgress = function (item, loaded, total) { };
    function onProgress(xhr) { if (xhr.lengthComputable) { } }
    function onError() { }
    scene.add(new THREE.AmbientLight(0xffffff, 0.6));
    directionalLight = new THREE.DirectionalLight(0xffffff, 0.6);
    directionalLight.position.set(3, -2, 2);
    scene.add(directionalLight);
    var geometry = new THREE.PlaneGeometry(200, 400);
    var material = new THREE.MeshBasicMaterial({ map: loadTexture(BG_64) });
    mPlan_Home = new THREE.Mesh(geometry, material);
    mPlan_Home.position.set(0, -120, -100);
    mPlan_Home.rotation.set(-.4, 0, 0);
    scene.add(mPlan_Home);
    for (let i = 0; i < 10; i++) {
        mTube.push(new Tube());
        mTube[i].group.position.set(i * 15, 0, 0);
        mTube[i].circle.name = "yogesh" + i;
    }
    mFlow = new Flow();
    Createtube();
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    document.body.appendChild(renderer.domElement);
    gameUI = new ThreeUI(renderer.domElement, 720);
    AssetLoader.add.image('assets/continue.png');
    AssetLoader.progressListener = function (progress) { };
    AssetLoader.load(function () {
        mTex_Continue = loadUI('assets/continue.png', 0, 200, 1);
        mTex_Continue.vx = 1.01;
        mTex_Continue.sx = 1;
        setScreen(GAMEPLAY);
    });
    document.addEventListener('keydown', dealWithKeyboard);
    if (isMobile.any()) {
        document.addEventListener('touchstart', e => { touchEvent(e, 0, 1); });
        document.addEventListener('touchmove', e => { touchEvent(e, 1, 1); });
        document.addEventListener('touchend', e => { touchEvent(e, 2, 1); });
    } else {
        document.addEventListener('mousedown', e => { touchEvent(e, 0, 0); });
        document.addEventListener('mousemove', e => { touchEvent(e, 1, 0); });
        document.addEventListener('mouseup', e => { touchEvent(e, 2, 0); });
    }
    window.addEventListener('resize', onWindowResize, false);
    Draw();
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    this.gameUI.resize();
    isResize = 5;
}
var mouse = new THREE.Vector2();
var coords = null;
var vec2 = new THREE.Vector2();
var isClick = false;
function touchEvent(e, type, sys) {
    CANVAS_WIDTH = window.innerWidth;
    CANVAS_HEIGHT = window.innerHeight;
    if (e.touches != null) {
        if (e.touches.length > 0) {
            mouse.x = (e.touches[0].pageX / window.innerWidth) * 2 - 1;
            mouse.y = -(e.touches[0].pageY / window.innerHeight) * 2 + 1;
            coords = { x: e.touches[0].pageX, y: e.touches[0].pageY };
            coords.x = coords.x - (window.innerWidth - gameUI.gameCanvas.getBoundingClientRect().width) / 2;
        }
    } else {
        mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
        mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
        coords = { x: e.clientX, y: e.clientY };
        coords.x = coords.x - (window.innerWidth - gameUI.gameCanvas.getBoundingClientRect().width) / 2;
        var elem = renderer.domElement, boundingRect = elem.getBoundingClientRect(),
            x = (event.clientX - boundingRect.left) * (elem.width / boundingRect.width),
            y = (event.clientY - boundingRect.top) * (elem.height / boundingRect.height);
        mouse.x = (x / CANVAS_WIDTH) * 2 - 1;
        mouse.y = -(y / CANVAS_HEIGHT) * 2 + 1;

    }
    raycaster.setFromCamera(mouse, camera);
    if (type == 2 && mouse.y > .8 && mPlayer.gOver == false) {
        gamereset();
    }
    if (mouse.y < .5)
        Handle_Game(type);

}
function Draw() {
    requestAnimationFrame(Draw);
    renderer.render(scene, camera);
    gameUI.render(renderer);
    if (mTex_Continue == null) {
        return;
    }
    if (mPlayer.gOver == false) {
        drawGame();

    } else {
        DrawTextureS(mTex_Continue, mTex_Continue.sx * 256, mTex_Continue.sx * 64);
        if (mTex_Continue.sx > 1.1) {
            mTex_Continue.vx = .995;
        }
        if (mTex_Continue.sx < 0.99) {
            mTex_Continue.vx = 1.005;
        }
        mTex_Continue.sx *= mTex_Continue.vx;
    }
    counter++;
    if (isResize > 0) {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
        this.gameUI.resize();
        isResize--;
    }
}
function drawGame() {
    if (mPlayer.anim == 0) {
        if ((mPlayer.vx < 0 && mTube[mPop.tubeNo].group.position.x > -2 + mTube[mPush.tubeNo].group.position.x - 15) ||
            (mPlayer.vx > 0 && mTube[mPop.tubeNo].group.position.x < -2 + mTube[mPush.tubeNo].group.position.x - 15)) {
            mTube[mPop.tubeNo].group.position.x += mPlayer.vx;
        }
        if (mTube[mPop.tubeNo].group.position.y < mTube[mPush.tubeNo].group.position.y + 18) {
            mTube[mPop.tubeNo].group.position.y += 1;
        } else if (mTube[mPop.tubeNo].group.rotation.z > -1.2) {
            mTube[mPop.tubeNo].group.rotation.z -= .2;
        } else {
            if (mFlow.gcyl1.scale.y > -4.2) {
                mFlow.gcyl1.scale.y -= .3;
                mFlow.gcyl1.visible = true;
                if (mFlow.gcyl1.scale.y < -4.2) {
                    mFlow.gcyl1.scale.y = -4.2;
                }
            } else if (mFlow.cyl2.visible == false) {
                mFlow.cyl2.visible = true;
            } else if (mFlow.gcyl3.scale.y < 5) {
                mFlow.gcyl3.visible = true;
                mFlow.gcyl3.scale.y += .3;
            } else {
                tubeEmpty(mPop.tubeNo, mPush.tubeNo, mPop.wNo, mPush.wNo + 1);
            }
            if (mTube[mPop.tubeNo].water[mPop.wNo].group.visible == false) {
                if (mPop.wNo > 0) {
                    mPop.wNo--;
                    mPush.wNo++;
                    if (mTube[mPop.tubeNo].water[mPop.wNo].color == mTube[mPush.tubeNo].water[mPush.wNo].color) {
                        mTube[mPush.tubeNo].water[mPush.wNo + 1].setColor(mTube[mPop.tubeNo].water[mPop.wNo].color);
                    } else {
                        mFlow.reset();
                        mTube[mPop.tubeNo].base.visible = false;
                        mPlayer.anim = 1;
                    }
                } else {
                    mFlow.reset();
                    mTube[mPop.tubeNo].base.visible = false;
                    mPlayer.anim = 1;
                }
            }
        }
    }
    if (mPlayer.anim == 1) {
        if (mTube[mPop.tubeNo].group.rotation.z < 0) {
            mTube[mPop.tubeNo].group.rotation.z += .2;
            if (mTube[mPop.tubeNo].group.rotation.z > 0) {
                mTube[mPop.tubeNo].group.rotation.z = 0;
            }
        } else if (mTube[mPop.tubeNo].group.position.x != mTube[mPop.tubeNo].ax) {
            if (mTube[mPop.tubeNo].group.position.x > mTube[mPop.tubeNo].ax) {
                mTube[mPop.tubeNo].group.position.x -= mPlayer.vx;
                if (mTube[mPop.tubeNo].group.position.x < mTube[mPop.tubeNo].ax) {
                    mTube[mPop.tubeNo].group.position.x = mTube[mPop.tubeNo].ax;
                }
            }
            if (mTube[mPop.tubeNo].group.position.x < mTube[mPop.tubeNo].ax) {
                mTube[mPop.tubeNo].group.position.x -= mPlayer.vx;
                if (mTube[mPop.tubeNo].group.position.x > mTube[mPop.tubeNo].ax) {
                    mTube[mPop.tubeNo].group.position.x = mTube[mPop.tubeNo].ax;
                }
            }
            if (mTube[mPop.tubeNo].group.position.y > mTube[mPop.tubeNo].ay) {
                mTube[mPop.tubeNo].group.position.y -= .9;
            }
        } else {
            mPlayer.anim = 2;
            mTube[mPop.tubeNo].group.position.set(mTube[mPop.tubeNo].ax, mTube[mPop.tubeNo].ay, mTube[mPop.tubeNo].az);
            checkGameOver();
        }
    }
}
function checkGameOver() {
    mPlayer.gOver = true;
    for (let i = 0; i < mTube.length && mPlayer.gOver == true; i++) {
        let k = 0;
        for (let j = 0; j < mTube[i].water.length; j++) {
            if (mTube[i].water[j].group.visible == true) {
                k++;
            }
        }
        if (k != 0 && k != mTube[i].water.length) {
            mPlayer.gOver = false;
        }
    }
    mTex_Continue.visible = mPlayer.gOver;
}
function tubeEmpty(ta, tb, emt, fil) {
    if (mTube[ta].water[emt].group.scale.y > .02) {
        mTube[ta].water[emt].group.scale.y -= .05;
        if (mTube[tb].water[fil].group.scale.y < 1) {
            mTube[tb].water[fil].group.scale.y += .05;
            mTube[tb].water[fil].group.visible = true;
        }
        if (mTube[ta].water[emt].group.scale.y < .02) {
            mTube[ta].water[emt].group.visible = false;
            mTube[tb].water[fil].group.scale.y = 1;
        }
    }
}
function Handle_Game(type) {
    if (mPlayer.anim == 2) {
        if (type == 0) {
            var col = [];
            mPlayer.tubes.forEach(element => { col.push(element.circle); });
            var intersects = raycaster.intersectObjects(col);
            for (let i = 0; i < col.length && intersects.length > 0; i++) {
                if (intersects[0].object == col[i]) {
                    console.log(mPlayer.tubes.length + " intersects " + i + " length = " + intersects.length);
                    mPop.tubeNo = i;
                }
            }
        }
        if (type == 1) {
            var col = [];
            mPlayer.tubes.forEach(element => { col.push(element.circle); });
            var intersects = raycaster.intersectObjects(col);
            for (let i = 0; i < col.length && intersects.length > 0; i++) {
                if (intersects[0].object == col[i]) {
                    mPush.tubeNo = i;
                }
            }
        }
        if (type == 2) {
            if (mPush.tubeNo != mPop.tubeNo) {
                mPop.reset();
                for (let i = mTube[mPop.tubeNo].water.length - 1; i >= 0; i--) {
                    if (mTube[mPop.tubeNo].water[i].group.visible == true && mPop.wNo == -1) {
                        mPop.wNo = i;
                        mPop.color = mTube[mPop.tubeNo].water[i].color;
                    }
                    if (mPop.color == mTube[mPop.tubeNo].water[i].color && mTube[mPop.tubeNo].water[i].group.visible == true) {
                        mPop.noSameClr++;
                        break;
                    }
                }
                mPush.reset();
                for (let i = mTube[mPush.tubeNo].water.length - 1; i >= 0; i--) {
                    if (mTube[mPush.tubeNo].water[i].group.visible == true && mPush.wNo == -1) {
                        mPush.wNo = i;
                        mPush.color = mTube[mPush.tubeNo].water[i].color;
                    }
                    if (mPush.color == mTube[mPush.tubeNo].water[i].color && mTube[mPush.tubeNo].water[i].group.visible == true) {
                        mPush.noSameClr++;
                        break;
                    }
                }
                console.log(((mPush.wNo < mTube[mPush.tubeNo].water.length - 1) + " " + (mPop.wNo >= 0) + "  " + ((mPop.wNo + mPush.wNo + 2 <= mTube[mPush.tubeNo].water.length))));
                if (mPush.wNo < mTube[mPush.tubeNo].water.length - 1 && mPop.wNo >= 0) {
                    if (mPop.noSameClr + mPush.noSameClr <= mTube[mPush.tubeNo].water.length && (mPop.color == mPush.color || mPush.color == -1)) {
                        mFlow.setColor(mPop.color);
                        mPlayer.anim = 0;
                        mFlow.group.position.set(mTube[mPush.tubeNo].group.position.x - 6, mTube[mPush.tubeNo].group.position.y + 15.5, 0);
                        mPlayer.vx = (mTube[mPush.tubeNo].group.position.x - mTube[mPop.tubeNo].group.position.x) * .1;
                        mTube[mPush.tubeNo].water[mPush.wNo + 1].setColor(mTube[mPop.tubeNo].water[mPop.wNo].color);
                    }
                }
            }
        }
    }
}
function setScreen(scr) {
    GameScreen = scr;
    gamereset();
}
function gamereset() {
    for (let i = 0; i < mTube.length; i++) {
        mTube[i].group.visible = false;
    }
    mPlayer.anim = 2;
    mFlow.reset();
    mPlayer.gOver = false;
    if (mPlayer.lvl == 1) {
        setLevelOne();
    }
    if (mPlayer.lvl == 2) {
        setLevelTwo();
    }
    mTex_Continue.visible = mPlayer.gOver;
}
function setLevelOne() {
    if (mPlayer.tubes.length > 0) {
        mPlayer.tubes.pop();
    }
    mPlayer.tubes.length = 0;
    for (let i = 0; i < 2; i++) {
        mPlayer.tubes.push(mTube[i]);
        mTube[i].set(-15 + i * 30, -70, 0);
        for (let j = 0; j < mTube[i].water.length; j++) {
            if (j == 0) {
                mTube[i].water[j].group.visible = true;
                mTube[i].water[j].group.scale.y = 1;
                mTube[i].base.visible = true;
                mTube[i].setColor(0);
            } else {
                mTube[i].water[j].group.visible = false;
                mTube[i].water[j].group.scale.y = .01;
            }
            mTube[i].water[j].setColor(0);
        }
    }
    mPlayer.vx = -2;
    mPush.tubeNo = 0; mPop.tubeNo = 1;
    mFlow.group.position.set(mTube[mPush.tubeNo].group.position.x - 6, mTube[mPush.tubeNo].group.position.y + 15.5, 0);
}

function setLevelTwo() {
    if (mPlayer.tubes.length > 0) {
        mPlayer.tubes.pop();
    }
    mPlayer.tubes.length = 0;
    var colr = [[0, 1], [-1, -1], [1, 0]];
    for (let i = 0; i < 3; i++) {
        mPlayer.tubes.push(mTube[i]);
        mTube[i].set(-30 + i * 30, -70, 0);
        for (let j = 0; j < mTube[i].water.length; j++) {
            mTube[i].water[j].group.visible = colr[i][j] >= 0;
            if (colr[i][j] >= 0) {
                mTube[i].water[j].setColor(colr[i][j]);
                mTube[i].water[j].group.scale.y = 1;
                if (j == 0) {
                    mTube[i].setColor(colr[i][j]);
                }
            } else {
                mTube[i].water[j].group.scale.y = .01;
                if (j == 0) {
                    mTube[i].base.visible = false;
                }
            }
        }
    }
    mPlayer.vx = -2;
    mPush.tubeNo = 0; mPop.tubeNo = 1;
    mFlow.group.position.set(mTube[mPush.tubeNo].group.position.x - 6, mTube[mPush.tubeNo].group.position.y + 15.5, 0);
}
function Handle_Menu(clickval) {
    if (mPlayer.lvl < 2) {
        mPlayer.lvl++;
        gamereset();
    } else {
        window.open("https://apps.apple.com/us/app/water-sort-3d/id1524105355");
    }
}