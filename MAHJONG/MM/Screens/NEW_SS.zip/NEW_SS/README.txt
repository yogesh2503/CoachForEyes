HERE'S MORE INFO FOR THE PROJECT - YOU CAN CONSIDER AND ADD THEM TO THE DESIGNS:

I’ve included what I would like the tiles to look like for the “fun” set choice. I grabbed clip art for the graphics…do you have access to art that may be used? Most are from Shutterstock. PLEASE SEE ATTACHED IMAGES


The dots I did (as you can see the sizes aren’t all exact!). I included the RGB numbers - and the same colors may be used for the Lucky You joker tile. A couple of the graphics aren’t exact but again thinking you may be able to do them…let me know. I added notes along side the tiles. PLEASE SEE ATTACHED IMAGES


Here are the colors…to be set against a lot of white background. SEE COLOR SWATCH

The logo is in process…the name is going to be : Let’s Mahj!
